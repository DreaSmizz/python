from distutils.core import setup

setup (
    name    = 'festor',
    version = '1.0.0',
    py_modules = ['festor'],
    author = 'asmith',
    author_email = 'asmith102781@gmail.com',
    url = 'http://www.google.com',
    description = 'A simple printer of nested lists',
)